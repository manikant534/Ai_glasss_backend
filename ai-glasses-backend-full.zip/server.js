require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const thinkspeakRoutes = require('./routes/thinkspeak');
const describeRoutes = require('./routes/describe');
const annotateRoutes = require('./routes/annotate');
const ttsRoutes = require('./routes/tts');
const geotagRoutes = require('./routes/geotag');

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// serve uploaded/generated files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// routes
app.use('/api/thinkspeak', thinkspeakRoutes);
app.use('/api/describe', describeRoutes);
app.use('/api/annotate', annotateRoutes);
app.use('/api/tts', ttsRoutes);
app.use('/api/geotag', geotagRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
