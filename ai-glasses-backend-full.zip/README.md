# AI Glasses Backend (Node.js)

This is a beginner-friendly Node.js backend that includes:
- /api/thinkspeak  -> GET ThingSpeak channel feeds
- /api/describe    -> POST image (form-data 'image') -> uses Google Vision (if GEMINI_API_KEY set)
- /api/annotate    -> POST image + text -> returns annotated PNG image
- /api/tts         -> POST {text} -> returns downloadable mp3 URL (uses Google TTS if key present)
- /api/geotag      -> POST {lat, lon, label?} -> returns downloadable JSON URL

## How to use

1. Copy `.env.example` to `.env` and set your keys.
2. `npm install`
3. `npm start`
4. Test endpoints with Postman or curl.

## Note about API keys

- GEMINI_API_KEY is used here to call Google Vision and Google TTS endpoints.
  If you have another API (e.g., Gemini Vision SDK), replace the implementation in routes/describe.js.
- The keys you provided will work only if they are valid. Keep them secret (don't commit `.env`).

## Deploying to Render

- Push this repository to GitHub.
- Create a Render Web Service, set Root Directory to the project root,
  set Environment to Node, Start Command `npm start`.
- Add environment variables in Render (do NOT upload .env).
