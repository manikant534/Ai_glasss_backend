// (optional) utilities for handling uploads - kept minimal for this starter project
const path = require('path');
module.exports = {
  uploadsDir: path.join(__dirname, '..', 'uploads')
};
