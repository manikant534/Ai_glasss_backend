const express = require('express');
const multer = require('multer');
const fs = require('fs-extra');
const path = require('path');
const axios = require('axios');

const router = express.Router();
const upload = multer({ dest: 'uploads/' });

// This endpoint accepts an image file (form-data field 'image') and
// uses Google Cloud Vision REST API to get labels/description.
//
// NOTE: You must set GEMINI_API_KEY (or a Google Cloud API key) in your .env or Render environment.
//
// Google Vision REST endpoint used here:
// POST https://vision.googleapis.com/v1/images:annotate?key=API_KEY
//
// If you prefer to connect to Gemini Vision, replace this implementation
// with the official Generative AI / Gemini Vision SDK call.

router.post('/', upload.single('image'), async (req, res) => {
  try {
    const file = req.file;
    if (!file) return res.status(400).json({ error: 'No image uploaded (field name must be "image")' });

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      // no key — return a placeholder response and echo filename
      const placeholder = {
        filename: file.filename,
        description: 'No GEMINI_API_KEY provided. Place your key in .env as GEMINI_API_KEY to enable vision.',
        labels: []
      };
      await fs.unlink(path.join(file.path)).catch(() => {});
      return res.json(placeholder);
    }

    const imageBytes = await fs.readFile(file.path, { encoding: 'base64' });

    const visionRequest = {
      requests: [
        {
          image: { content: imageBytes },
          features: [
            { type: 'LABEL_DETECTION', maxResults: 10 },
            { type: 'WEB_DETECTION', maxResults: 5 },
            { type: 'IMAGE_PROPERTIES', maxResults: 5 }
          ]
        }
      ]
    };

    const visionUrl = `https://vision.googleapis.com/v1/images:annotate?key=${apiKey}`;
    const r = await axios.post(visionUrl, visionRequest, { headers: { 'Content-Type': 'application/json' } });

    // parse useful info
    const resp = r.data.responses && r.data.responses[0] ? r.data.responses[0] : {};
    const labels = (resp.labelAnnotations || []).map(l => ({ description: l.description, score: l.score }));
    const web = resp.webDetection || {};
    const description = labels.length ? labels[0].description : (web.bestGuessLabels && web.bestGuessLabels[0] ? web.bestGuessLabels[0].label : '');

    await fs.unlink(path.join(file.path)).catch(() => {});

    res.json({ description, labels, web });
  } catch (err) {
    console.error('Describe error', err.message || err);
    res.status(500).json({ error: 'Failed to describe image', details: err.message });
  }
});

module.exports = router;
