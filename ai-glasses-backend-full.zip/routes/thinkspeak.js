const express = require('express');
const axios = require('axios');
const router = express.Router();

// Uses the public ThingSpeak channel provided by the user
// Example URL:
// https://api.thingspeak.com/channels/3099447/feeds.json?results=2

router.get('/', async (req, res) => {
  try {
    const CHANNEL_ID = process.env.THINKSPEAK_CHANNEL_ID || '3099447';
    const READ_KEY = process.env.THINKSPEAK_READ_API_KEY || '';
    const results = req.query.results || 2;
    const url = `https://api.thingspeak.com/channels/${CHANNEL_ID}/feeds.json?results=${results}${READ_KEY ? '&api_key=' + READ_KEY : ''}`;
    const r = await axios.get(url);
    const feeds = r.data.feeds || [];
    // map to friendly format; fields may differ based on your channel setup
    const parsed = feeds.map(f => ({
      created_at: f.created_at,
      field1: f.field1,
      field2: f.field2,
      raw: f
    }));
    res.json({ channel: r.data.channel || {}, feeds: parsed });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: 'Failed to fetch ThingSpeak data', details: err.message });
  }
});

module.exports = router;
