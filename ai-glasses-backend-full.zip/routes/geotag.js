const express = require('express');
const fs = require('fs-extra');
const path = require('path');
const router = express.Router();

// This endpoint accepts geotag data from frontend and returns a small JSON file
// that the user can download (no database/persistent server storage).
// POST body: { lat: 12.34, lon: 56.78, label: 'optional' }

router.post('/', async (req, res) => {
  try {
    const { lat, lon, label } = req.body;
    if (typeof lat === 'undefined' || typeof lon === 'undefined') {
      return res.status(400).json({ error: 'lat and lon are required' });
    }
    const payload = {
      lat, lon, label: label || null,
      time: new Date().toISOString()
    };
    const filename = `geotag_${Date.now()}.json`;
    const filepath = path.join('uploads', filename);
    await fs.writeJson(filepath, payload, { spaces: 2 });
    return res.json({ url: `${req.protocol}://${req.get('host')}/uploads/${filename}`, payload });
  } catch (err) {
    console.error('geotag error', err);
    res.status(500).json({ error: 'Failed to save geotag', details: err.message });
  }
});

module.exports = router;
