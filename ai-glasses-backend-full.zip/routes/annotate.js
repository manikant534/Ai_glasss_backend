const express = require('express');
const multer = require('multer');
const sharp = require('sharp');
const fs = require('fs-extra');
const path = require('path');

const router = express.Router();
const upload = multer({ dest: 'uploads/' });

router.post('/', upload.single('image'), async (req, res) => {
  try {
    const file = req.file;
    const text = req.body.text || req.body.description || 'No description';

    if (!file) return res.status(400).json({ error: 'Image missing' });

    const input = sharp(file.path);
    const metadata = await input.metadata();

    // create SVG overlay
    const padding = 20;
    const fontSize = Math.max(18, Math.floor(metadata.width / 20));
    const svg = `<svg width="${metadata.width}" height="${metadata.height}">
      <rect x="0" y="${metadata.height - (fontSize + padding*2)}" width="${metadata.width}" height="${fontSize + padding*2}" fill="rgba(0,0,0,0.5)"/>
      <text x="${padding}" y="${metadata.height - padding - 4}" font-size="${fontSize}" fill="#fff" font-family="Arial, sans-serif">${escapeXml(text)}</text>
    </svg>`;

    const annotatedBuffer = await input
      .composite([{ input: Buffer.from(svg), top: 0, left: 0 }])
      .png()
      .toBuffer();

    // clean uploaded file (optional)
    await fs.unlink(path.join(file.path)).catch(() => {});

    res.set('Content-Type', 'image/png');
    res.send(annotatedBuffer);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Annotation failed', details: err.message });
  }
});

function escapeXml(unsafe) {
  return unsafe.replace(/[&<>'"]/g, function (c) {
    switch (c) {
      case '&': return '&amp;';
      case '<': return '&lt;';
      case '>': return '&gt;';
      case '\'': return '&apos;';
      case '"': return '&quot;';
    }
  });
}

module.exports = router;
