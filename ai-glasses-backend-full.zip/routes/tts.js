const express = require('express');
const axios = require('axios');
const fs = require('fs-extra');
const path = require('path');
const router = express.Router();

// Simple TTS using Google Cloud Text-to-Speech REST API.
// Requires a valid API key in GEMINI_API_KEY environment variable (or separate key).
// If no key is provided, endpoint will return the text back for frontend TTS.

router.post('/', async (req, res) => {
  try {
    const text = req.body.text;
    if (!text) return res.status(400).json({ error: 'Text is required in JSON body { "text": "..." }' });

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      // No key — return text; frontend can use Web Speech API for TTS
      return res.json({ message: 'No GEMINI_API_KEY provided. Return text for frontend TTS.', text });
    }

    const url = `https://texttospeech.googleapis.com/v1/text:synthesize?key=${apiKey}`;
    const body = {
      input: { text },
      voice: { languageCode: 'en-US', ssmlGender: 'NEUTRAL' },
      audioConfig: { audioEncoding: 'MP3' }
    };

    const r = await axios.post(url, body, { headers: { 'Content-Type': 'application/json' }});
    if (r.data && r.data.audioContent) {
      const audioBuffer = Buffer.from(r.data.audioContent, 'base64');
      const filename = `tts_${Date.now()}.mp3`;
      const filepath = path.join('uploads', filename);
      await fs.writeFile(filepath, audioBuffer);
      // return a downloadable URL (served from /uploads)
      return res.json({ url: `${req.protocol}://${req.get('host')}/uploads/${filename}` });
    } else {
      return res.status(500).json({ error: 'No audio returned from TTS API' });
    }
  } catch (err) {
    console.error('TTS error', err.message || err);
    res.status(500).json({ error: 'TTS failed', details: err.message });
  }
});

module.exports = router;
